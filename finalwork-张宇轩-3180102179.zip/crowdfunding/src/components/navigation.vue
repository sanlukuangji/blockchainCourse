导航栏页

<template>
  <div class="mainNav" style="position: relative">
    <a class="navButton" :href="index">区块链大作业：众筹平台</a>
    <a class="navButtonSmall" :href="projectList">浏览项目</a>
    <a class="navButtonSmall" :href="myProject">我的众筹</a>
    <a class="navButtonSmall" :href="launch">发起众筹</a>
  </div>
</template>

<script>

import {getAccount, Authenticate, addListener} from "../server/serve"

export default {
  name: "navigation",
  stores: {
    logged: "state.logged",
    loggedUser: 'state.currentUser',
  },
  data() {
    return {
      account: "",
      index: "/",
      projectList: "/ProjectList",
      myProject: "/MyProject",
      launch: "/Launch",
    };
  },

  mounted() {
  
  },

  async created () {
    var that = this
    async function updateAccount() {
      await Authenticate();
      try {
        that.account = await getAccount()
      } catch (e) {
        console.log(e);
        alert("获取账户信息失败")
      }
    }
    updateAccount();
    addListener(updateAccount)
    return {Authenticate}
  },

  methods: {
  },
};
</script>

<style scoped>
.mainNav {
  background-color: #10f141;
  height: 100px;
  padding: 0px;
  font-size: 16px;
  font-family: 微软雅黑;
  color: rgb(55, 10, 219);
  /* width: 100%; */
  /* border: 1px solid black; */
}

.navButton {
  font-size: 60px;
  color: rgb(43, 8, 243);
  text-decoration: none;
  position: relative;
  top: 11px;
  margin: 0 10px;
}

.navButton :visited {
  color: rgb(228, 10, 10);
  text-decoration: none;
}

.navButtonSmall {
  font-size: 16px;
  color: rgb(252, 6, 6);
  /*text-decoration: none;*/
  position: relative;
  top: 10px;
  margin: 0 10px;
}

.navButtonSmall :visited {
  color: white;
  text-decoration: none;
}

.positionRight {
  position: absolute;
  right: 160px;
  top: 14px;
}

.el-dropdown-link {
  cursor: pointer;
  color: white;
}

.el-icon-arrow-down {
  font-size: 12px;
}
</style>